angular.module('myApp', ['ui.router']);

var Config = function($stateProvider, $urlRouterProvider) {
  $stateProvider.state('app', {
    url: "/",
    views: {
      'panelOne': {
        template: "<h1>Panel 1</h1> <div ui-view='panelOneContent'></div>"
      },
      'panelTwo': {
        template: "<h1>Panel 2</h1> <div ui-view='panelTwoContent'></div>"
      },
      'panelThree': {
        template: "<h1>Panel 3</h1>"
      }
    }
  })

  // Panel One ================================================================
  .state('app.panelOne', {
    abstract: true,
    url: "panel1",
    views: {
      'panelOneContent': {
        template: '<h2>Panel 1 Content</h2> <div ui-view="content"></div>'
      }
    }
  })
  .state('app.panelOne.childOne', {
    url: "/child1",
    views: {
      'content': {
        template: 'Panel 1 child 1'
      }
    }
  })
  .state('app.panelOne.childTwo', {
    url: "/child2",
    views: {
      'content': {
        template: 'Panel 1 child 2'
      }
    }
  })

  // Panel Two ================================================================
  .state('app.panelTwo', {
    abstract: true,
    url: "panel2",
    views: {
      'panelTwoContent': {
        template: '<h2>Panel 2 Content</h2> <div ui-view="content"></div>'
      }
    }
  })
  .state('app.panelTwo.childOne', {
    url: "/child1",
    views: {
      'content': {
        template: 'Panel 2 child 1'
      }
    }
  })
  .state('app.panelTwo.childTwo', {
    url: "/child2",
    views: {
      'content': {
        template: 'Panel 2 child 2'
      }
    }
  })
  .state('app.panelTwo.childThree', {
    url: "/child3",
    views: {
      'content': {
        template: 'Panel 2 child 3'
      },
      'panelOne@': {
        template: '<h2>This one takes over Panel One</h2>'
      }
    }
  });

  $urlRouterProvider.otherwise("/");
};

angular.module('myApp').config(Config);
Config.$inject = ['$stateProvider', '$urlRouterProvider'];
